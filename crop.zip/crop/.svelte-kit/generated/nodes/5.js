import * as shared from "../../../src/routes/sverdle/how-to-play/+page.js";
export { shared };
export { default as component } from "../../../src/routes/sverdle/how-to-play/+page.svelte";