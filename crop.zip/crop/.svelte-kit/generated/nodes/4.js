export { default as component } from "../../../src/routes/sverdle/+page.svelte";
export const server = true;