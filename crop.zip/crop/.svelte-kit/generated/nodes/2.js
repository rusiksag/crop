import * as shared from "../../../src/routes/+page.js";
export { shared };
export { default as component } from "../../../src/routes/+page.svelte";