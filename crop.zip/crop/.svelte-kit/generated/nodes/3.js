import * as shared from "../../../src/routes/about/+page.js";
export { shared };
export { default as component } from "../../../src/routes/about/+page.svelte";